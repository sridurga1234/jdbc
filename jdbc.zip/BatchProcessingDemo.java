package newdb;

import java.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.mysql.cj.xdevapi.Statement;

public class BatchProcessingDemo {

	public static void main(String[] args) throws Exception {
	// TODO Auto-generated method stub
	String url="jdbc:mysql://localhost:3306/project_database";
	String username="root";
	String password="Atchu@140698";
	PreparedStatement ps=null;

	/*String sql1 ="create table Book(emp_name varchar(30),emp_id int not null)
	String sql2 ="insert into employee(emp_name,emp_id) values('suma','1')";
	String sql3 ="insert into employee(emp_name,emp_id) values('sai','2')";
	String sql6 ="insert into employee(emp_name,emp_id) values('ravi','3')";
	String sql7 ="insert into employee(emp_name,emp_id) values('vyshu','4')";*/
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection(url,username,password);         //creating the connection
	Statement st= (Statement) con.createStatement();                                   //creating the statements
	long starttime=System.currentTimeMillis();
	System.out.println(starttime);
	((java.sql.Statement) st).addBatch("insert into Book values(1,'java')");
	 ((java.sql.Statement) st).addBatch("insert into Book values(2,'dbms')");
	 ((java.sql.Statement) st).addBatch("insert into Book values(3,'c++')");
	st.execute();


	//st.executeUpdate(sql1);
	//System.out.println("Table Created");


	//st.executeUpdate(sql2);                   //execute the query
	//st.executeUpdate(sql3);
	//st.executeUpdate(sql6);
	//st.executeUpdate(sql7);
	//System.out.println("INSERTED");


	//System.out.println("the values in table are");
	//ResultSet rs=(ResultSet) st.executeQuery("select * from details");
	/*while((boolean)rs.next())
	{
	System.out.println("Name:" + rs.getString(1)+ "  " + "id:"+rs.getInt(2));
	}*/

	//String sql5="update details set emp_name='lakshmi' where emp_name='sai'";
	//st.executeUpdate(sql5);
	//System.out.println("values updated");

	/*String sq4="select * from details where emp_id=? and emp_name=?";

	ps=con.prepareStatement(sq4);
	ps.setString(2,"ravi");
	ps.setInt(1,3);
	ResultSet rs1=ps.executeQuery();
	if(rs1.next()){
	System.out.println("success");
	}else{
	System.out.println("unsuccess");
	}*/



	//String sql4="delete from details where emp_id=1";
	//st.executeUpdate(sql4);
	//System.out.println("values deleted");


	((Connection) st).close();
	con.close(); //closing the connection

	}

	}
