package newdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.exceptions.RSAException;
import com.mysql.cj.protocol.Resultset;

public class ProjectSample1 {

public static void main(String[] args) throws Exception {
String url="jdbc:mysql://localhost:3306/project_database";
String username="root";
String password="Atchu@140698";

	Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection(url,username,password);
Statement st=con.createStatement();
/*String sql1="create table Customers(cust_id int,cust_name varchar(30),cust_add varchar(50),age int)";
String sql2="insert into Customers(cust_id,cust_name,cust_add,age) values(1,'priya','hyd',21)";
String sql5="insert into Customers(cust_id,cust_name,cust_add,age) values(2,'sri','bangalore',22)";
String sql6="insert into Customers(cust_id,cust_name,cust_add,age) values(3,'durga','tpg',24)";
String sql7="insert into Customers(cust_id,cust_name,cust_add,age) values(4,'sasi','tnk',25)";
//st.executeUpdate(sql1);
System.out.println("Table Created");
st.executeUpdate(sql2);
st.executeUpdate(sql5);
st.executeUpdate(sql6);
st.executeUpdate(sql7);
System.out.println("Values Inserted");
Resultset resultset = (Resultset) st.executeQuery("select * from customers");
while(((ResultSet) resultset).next()){  
	System.out.println(((ResultSet) resultset).getInt(1)+"  "+((ResultSet) resultset).getString(2)+"  "+((ResultSet)resultset).getString(3));
	
}
/*String sql3 = "update  Customers set cust_name = 'sri' where cust_id='1'";
st.executeUpdate(sql3);
System.out.println("updated");
String sql4 = "delete  from customers where age=21";
st.executeUpdate(sql4);*/
PreparedStatement stmt=con.prepareStatement("delete from customers where id=?"); 

st.close();
con.close();

}
}
