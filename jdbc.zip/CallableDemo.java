package newdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.CallableStatement;

public class CallableDemo {
	public static void main(String[] args) throws Exception {
		String url="jdbc:mysql://localhost:3306/project_database";
		String username="root";
		String password="Atchu@140698";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			Statement st=con.createStatement();
			CallableStatement statement =  (CallableStatement) con.prepareCall("{Call INSERTUSER(?,?)}");
			statement.setInt(1, 10);
			statement.setString(2, "CORE JAVA");
			statement.execute();
			System.out.println("success");
			con.close();
			
		}
		catch(SQLException e)
		{
			
		}

}
}
